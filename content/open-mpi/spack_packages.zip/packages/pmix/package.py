# Copyright 2013-2021 Lawrence Livermore National Security, LLC and other
# Spack Project Developers. See the top-level COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)
import os

from spack import *


class Pmix(AutotoolsPackage):
    """The Process Management Interface (PMI) has been used for quite some
       time as a means of exchanging wireup information needed for
       interprocess communication. However, meeting the significant
       orchestration challenges presented by exascale systems requires
       that the process-to-system interface evolve to permit a tighter
       integration between the different components of the parallel
       application and existing and future SMS solutions.

       PMI Exascale (PMIx) addresses these needs by providing an extended
       version of the PMI definitions specifically designed to support
       exascale and beyond environments by: (a) adding flexibility to the
       functionality expressed in the existing APIs, (b) augmenting the
       interfaces with new APIs that provide extended capabilities, (c)
       forging a collaboration between subsystem providers including
       resource manager, fabric, file system, and programming library
       developers, (d) establishing a standards-like body for maintaining
       the definitions, and (e) providing a reference implementation of the
       PMIx standard that demonstrates the desired level of scalability
       while maintaining strict separation between it and the standard
       itself."""

    git      = "https://gitlab.inria.fr/dynres/dyn-procs/openpmix"
    maintainers = ['x-DHuber']

    version('dyn', branch='main')
    
    variant('pmi_backwards_compatibility',
            default=True,
            description="Toggle pmi backwards compatibility")

    variant('restful',
            default=False,
            description="allow a PMIx server to request services from "
            "a system-level REST server")

    variant("python", default=False, when="@4.1.2:", description="Enable python bindigs")

    variant('docs',
            default=False,
            description='Build manpages')

    depends_on('libevent@2.0.20:2.0.22,2.1.8')
    depends_on('hwloc@2.4.1', when='@dyn')
    depends_on('hwloc@1.11.0:1.11,2.0.1:', when='@3.0.0:')
    depends_on("m4", type=("build"), when="@dyn")
    depends_on("autoconf", type=("build"), when="@dyn")
    depends_on("automake", type=("build"), when="@dyn")
    depends_on("libtool", type=("build"), when="@dyn")
    depends_on("perl", type=("build"), when="@dyn")
    depends_on('curl', when="+restful")
    depends_on('jansson@2.11:', when="+restful")
    depends_on('pandoc', type='build', when='+docs')
    depends_on("pkgconfig", type="build")
    depends_on("python", when="+python")
    depends_on("py-cython", when="+python")

    conflicts('@:3.9.9', when='+restful')

    def autoreconf(self, spec, prefix):
        """Only needed when building from git checkout"""
        # If configure exists nothing needs to be done
        if os.path.exists(self.configure_abs_path):
            return
        # Else bootstrap with autotools
        perl = which('perl')
        perl('./autogen.pl')

    def configure_args(self):

        spec = self.spec
        config_args = [
            '--enable-shared',
            '--enable-static'
        ]

        if '+pmi_backwards_compatibility' in self.spec:
            config_args.append('--enable-pmi-backward-compatibility')
        else:
            config_args.append('--disable-pmi-backward-compatibility')

        if '~docs' in self.spec:
            config_args.append('--disable-man-pages')

        # libevent support
        config_args.append(
            '--with-libevent={0}'.format(spec['libevent'].prefix))

        # Versions < 2.1.1 have a bug in the test code that *sometimes*
        # causes problems on strict alignment architectures such as
        # aarch64.  Work-around is to just not build the test code.
        if (self.spec.satisfies('target=aarch64:') and
                self.spec.version < Version('2.1.1')):
            config_args.append('--without-tests-examples')

        # Versions >= 3.0 also use hwloc
        if self.spec.version >= Version('3.0.0'):
            config_args.append('--with-hwloc={0}'.format(spec['hwloc'].prefix))

        return config_args
